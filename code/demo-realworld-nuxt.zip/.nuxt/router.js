import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _ca33709c = () => interopDefault(import('..\\pages\\editor.vue' /* webpackChunkName: "pages_editor" */))
const _048b59b4 = () => interopDefault(import('..\\pages\\login.vue' /* webpackChunkName: "pages_login" */))
const _0a489334 = () => interopDefault(import('..\\pages\\profile.vue' /* webpackChunkName: "pages_profile" */))
const _1850c028 = () => interopDefault(import('..\\pages\\settings.vue' /* webpackChunkName: "pages_settings" */))
const _4d8c6c46 = () => interopDefault(import('..\\pages\\signup.vue' /* webpackChunkName: "pages_signup" */))
const _61817819 = () => interopDefault(import('..\\pages\\article\\_slug.vue' /* webpackChunkName: "pages_article__slug" */))
const _3ae3b69d = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/editor",
    component: _ca33709c,
    name: "editor"
  }, {
    path: "/login",
    component: _048b59b4,
    name: "login"
  }, {
    path: "/profile",
    component: _0a489334,
    name: "profile"
  }, {
    path: "/settings",
    component: _1850c028,
    name: "settings"
  }, {
    path: "/signup",
    component: _4d8c6c46,
    name: "signup"
  }, {
    path: "/article/:slug?",
    component: _61817819,
    name: "article-slug"
  }, {
    path: "/",
    component: _3ae3b69d,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}

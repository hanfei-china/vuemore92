
export default () => ({
  user: null
})

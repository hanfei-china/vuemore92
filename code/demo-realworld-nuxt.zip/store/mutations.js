
export default {
  setUser (state, user) {
    state.user = user
  }
}
